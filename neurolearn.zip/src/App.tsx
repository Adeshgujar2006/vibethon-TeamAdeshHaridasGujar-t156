import React, { useState, useEffect } from 'react';
import { Brain, BookOpen, Zap, Trophy, Mail, ShieldAlert, ShieldCheck, CheckCircle2, XCircle, LogIn, LogOut, Layout, ArrowRight, ChevronRight, Star } from 'lucide-react';

// --- Static Data ---
const NEURAL_NET_CONTENT = {
  title: 'Neural Networks',
  description: 'Understand how computers mimic the human brain to learn.',
  content: `
# What are Neural Networks?

Neural Networks are a series of algorithms that endeavor to recognize underlying relationships in a set of data through a process that mimics the way the human brain operates.

## The Structure
1. **Input Layer**: Receives raw data (like pixels of an image).
2. **Hidden Layers**: Where the actual learning happens. They detect patterns.
3. **Output Layer**: Provides the final prediction (like "This is a cat").

### Simple Analogy
Think of a Neural Network like a **Team of Experts**. Each expert looks at a tiny part of a puzzle and passes their opinion to the next person. Together, they solve the whole puzzle!
  `,
  quiz: [
    {
      question: 'What does a Neural Network mimic?',
      options: ['A computer processor', 'The human brain', 'A spider web', 'A library'],
      correctAnswer: 1,
      explanation: 'Neural networks are designed to mimic the way the human brain operates.'
    },
    {
      question: 'Which layer provides the final prediction?',
      options: ['Input Layer', 'Hidden Layer', 'Output Layer', 'Storage Layer'],
      correctAnswer: 2,
      explanation: 'The Output Layer is the final stage that gives the result.'
    },
    {
      question: 'What happens in the Hidden Layers?',
      options: ['Data is deleted', 'Patterns are detected', 'The user logs in', 'The screen turns off'],
      correctAnswer: 1,
      explanation: 'Hidden layers are where the network processes information to find patterns.'
    }
  ]
};

const DUMMY_LEADERBOARD = [
  { name: 'Alex AI', score: 1500 },
  { name: 'Machine Mike', score: 1200 },
  { name: 'Data Dana', score: 900 },
  { name: 'Logic Leo', score: 600 },
];

// --- Main App Component ---

export default function App() {
  const [username, setUsername] = useState<string | null>(localStorage.getItem('neurolearn_user'));
  const [score, setScore] = useState<number>(parseInt(localStorage.getItem('neurolearn_score') || '0'));
  const [streak, setStreak] = useState<number>(parseInt(localStorage.getItem('neurolearn_streak') || '0'));
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loginInput, setLoginInput] = useState('');

  // Save to localStorage whenever values change
  useEffect(() => {
    if (username) localStorage.setItem('neurolearn_user', username);
    localStorage.setItem('neurolearn_score', score.toString());
    localStorage.setItem('neurolearn_streak', streak.toString());
  }, [username, score, streak]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginInput.trim()) {
      setUsername(loginInput.trim());
      setStreak(1); // Start streak on first login
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('neurolearn_user');
    localStorage.removeItem('neurolearn_score');
    localStorage.removeItem('neurolearn_streak');
    setUsername(null);
    setScore(0);
    setStreak(0);
    setActiveTab('dashboard');
  };

  const updateProgress = (points: number) => {
    setScore(prev => prev + points);
    setStreak(prev => prev + 1);
  };

  if (!username) {
    return (
      <div className="min-h-screen bg-blue-600 flex items-center justify-center p-6 font-sans">
        <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl p-10 space-y-8 text-center animate-in zoom-in duration-500">
          <div className="flex justify-center">
            <div className="p-4 bg-blue-600 rounded-2xl">
              <Brain className="w-12 h-12 text-white" />
            </div>
          </div>
          <div className="space-y-2">
            <h1 className="text-4xl font-black tracking-tighter text-blue-600">NEUROLEARN</h1>
            <p className="text-gray-500">Master AIML concepts with ease.</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-4">
            <input
              type="text"
              placeholder="Enter your username"
              value={loginInput}
              onChange={(e) => setLoginInput(e.target.value)}
              className="w-full p-4 rounded-xl border-2 border-gray-100 focus:border-blue-600 outline-none transition-all text-center text-lg font-medium"
              required
            />
            <button type="submit" className="w-full py-4 bg-blue-600 text-white rounded-xl font-bold text-lg shadow-lg hover:bg-blue-700 transition-all flex items-center justify-center gap-2">
              <LogIn className="w-5 h-5" /> Start Learning
            </button>
          </form>
        </div>
      </div>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard username={username} score={score} streak={streak} onStart={() => setActiveTab('learn')} />;
      case 'learn':
        return <LearnModule onComplete={() => setActiveTab('quiz')} />;
      case 'quiz':
        return <QuizModule onFinish={(points) => { updateProgress(points); setActiveTab('dashboard'); }} />;
      case 'simulation':
        return <SimulationModule onComplete={() => { setStreak(s => s + 1); }} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-white border-r p-6 flex flex-col gap-8">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-600 rounded-lg">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <span className="font-black text-xl tracking-tighter text-blue-600">NEUROLEARN</span>
        </div>

        <nav className="flex-1 space-y-2">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: Layout },
            { id: 'learn', label: 'Learn', icon: BookOpen },
            { id: 'simulation', label: 'Simulation', icon: Zap },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                activeTab === item.id || (activeTab === 'quiz' && item.id === 'learn')
                  ? 'bg-blue-50 text-blue-600 font-bold' 
                  : 'text-gray-500 hover:bg-gray-100'
              }`}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
        </nav>

        <button onClick={handleLogout} className="flex items-center gap-3 px-4 py-3 text-red-500 hover:bg-red-50 rounded-xl transition-all font-medium">
          <LogOut className="w-5 h-5" /> Logout
        </button>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 md:p-12 max-w-5xl mx-auto w-full overflow-y-auto">
        {renderContent()}
      </main>
    </div>
  );
}

// --- Sub-Components ---

function Dashboard({ username, score, streak, onStart }: any) {
  const leaderboard = [...DUMMY_LEADERBOARD, { name: username, score }]
    .sort((a, b) => b.score - a.score);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="bg-blue-600 text-white p-8 rounded-3xl shadow-xl">
        <h2 className="text-3xl font-bold mb-2">Welcome back, {username}!</h2>
        <p className="text-blue-100">You're making great progress in your AIML journey.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border shadow-sm flex items-center gap-4">
          <div className="p-4 bg-yellow-100 rounded-xl">
            <Trophy className="w-8 h-8 text-yellow-600" />
          </div>
          <div>
            <p className="text-sm text-gray-500 font-bold uppercase tracking-wider">Total Score</p>
            <p className="text-3xl font-black text-blue-600">{score}</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl border shadow-sm flex items-center gap-4">
          <div className="p-4 bg-orange-100 rounded-xl">
            <Zap className="w-8 h-8 text-orange-600" />
          </div>
          <div>
            <p className="text-sm text-gray-500 font-bold uppercase tracking-wider">Current Streak</p>
            <p className="text-3xl font-black text-orange-600">{streak} Days</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <h3 className="text-xl font-bold flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-600" /> Recommended Module
          </h3>
          <div className="bg-white p-8 rounded-3xl border shadow-sm hover:border-blue-200 transition-all group cursor-pointer" onClick={onStart}>
            <div className="flex justify-between items-start mb-4">
              <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-bold uppercase tracking-wider">Intermediate</span>
              <Brain className="w-8 h-8 text-blue-600 group-hover:scale-110 transition-transform" />
            </div>
            <h4 className="text-2xl font-bold mb-2">{NEURAL_NET_CONTENT.title}</h4>
            <p className="text-gray-600 mb-6">{NEURAL_NET_CONTENT.description}</p>
            <button className="flex items-center text-blue-600 font-bold gap-2">
              Start Learning <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="space-y-6">
          <h3 className="text-xl font-bold flex items-center gap-2">
            <Star className="w-5 h-5 text-yellow-500" /> Leaderboard
          </h3>
          <div className="bg-white rounded-2xl border shadow-sm overflow-hidden">
            <div className="divide-y">
              {leaderboard.map((user, i) => (
                <div key={i} className={`p-4 flex items-center justify-between ${user.name === username ? 'bg-blue-50' : ''}`}>
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-gray-300 w-4">#{i + 1}</span>
                    <span className={`font-bold ${user.name === username ? 'text-blue-600' : 'text-gray-700'}`}>{user.name}</span>
                  </div>
                  <span className="font-black text-blue-600">{user.score}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function LearnModule({ onComplete }: any) {
  return (
    <div className="space-y-8 animate-in slide-in-from-right-4 duration-300">
      <div className="bg-white p-10 rounded-3xl border shadow-sm space-y-8">
        <h2 className="text-4xl font-black text-blue-600">{NEURAL_NET_CONTENT.title}</h2>
        <div className="prose prose-blue max-w-none space-y-6">
          <p className="text-xl text-gray-700 leading-relaxed whitespace-pre-wrap">
            {NEURAL_NET_CONTENT.content.replace(/#+ /g, '').trim()}
          </p>
        </div>
        <button onClick={onComplete} className="w-full py-5 bg-blue-600 text-white rounded-2xl font-bold text-xl shadow-lg hover:bg-blue-700 transition-all flex items-center justify-center gap-3">
          Take the Quiz <ChevronRight className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
}

function QuizModule({ onFinish }: any) {
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);

  const handleSelect = (idx: number) => {
    if (answered) return;
    setSelected(idx);
    setAnswered(true);
    if (idx === NEURAL_NET_CONTENT.quiz[current].correctAnswer) {
      setScore(s => s + 1);
    }
  };

  const handleNext = () => {
    if (current < NEURAL_NET_CONTENT.quiz.length - 1) {
      setCurrent(c => c + 1);
      setSelected(null);
      setAnswered(false);
    } else {
      onFinish(score * 100);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-in zoom-in duration-300">
      <div className="flex justify-between items-center text-sm font-bold text-gray-400 uppercase tracking-widest">
        <span>Question {current + 1} of {NEURAL_NET_CONTENT.quiz.length}</span>
        <span className="text-blue-600">Points: {score * 100}</span>
      </div>

      <div className="bg-white p-10 rounded-3xl border shadow-sm space-y-8">
        <h3 className="text-2xl font-bold text-gray-800">{NEURAL_NET_CONTENT.quiz[current].question}</h3>
        <div className="space-y-3">
          {NEURAL_NET_CONTENT.quiz[current].options.map((opt, i) => (
            <button
              key={i}
              onClick={() => handleSelect(i)}
              className={`w-full p-5 text-left rounded-2xl border-2 transition-all font-bold text-lg ${
                answered 
                  ? i === NEURAL_NET_CONTENT.quiz[current].correctAnswer 
                    ? 'border-green-500 bg-green-50 text-green-700' 
                    : selected === i ? 'border-red-500 bg-red-50 text-red-700' : 'border-gray-100 text-gray-400'
                  : selected === i ? 'border-blue-600 bg-blue-50 text-blue-600' : 'border-gray-100 hover:border-blue-200 text-gray-600'
              }`}
            >
              <div className="flex justify-between items-center">
                <span>{opt}</span>
                {answered && i === NEURAL_NET_CONTENT.quiz[current].correctAnswer && <CheckCircle2 className="w-6 h-6" />}
                {answered && selected === i && i !== NEURAL_NET_CONTENT.quiz[current].correctAnswer && <XCircle className="w-6 h-6" />}
              </div>
            </button>
          ))}
        </div>
        {answered && (
          <div className="p-6 bg-gray-50 rounded-2xl text-gray-600 italic border-l-4 border-blue-600">
            {NEURAL_NET_CONTENT.quiz[current].explanation}
          </div>
        )}
        {answered && (
          <button onClick={handleNext} className="w-full py-5 bg-gray-900 text-white rounded-2xl font-bold text-lg shadow-xl hover:bg-black transition-all">
            {current < NEURAL_NET_CONTENT.quiz.length - 1 ? 'Next Question' : 'Finish & Collect Points'}
          </button>
        )}
      </div>
    </div>
  );
}

function SimulationModule({ onComplete }: any) {
  const [email, setEmail] = useState('');
  const [result, setResult] = useState<{ isSpam: boolean; confidence: number } | null>(null);

  const spamKeywords = ['winner', 'prize', 'urgent', 'account', 'verify', 'bank', 'lottery', 'free', 'click here', 'congratulations'];

  const analyze = () => {
    const lower = email.toLowerCase();
    const matches = spamKeywords.filter(word => lower.includes(word));
    const confidence = Math.min(matches.length * 20, 99);
    setResult({ isSpam: matches.length > 0, confidence });
    onComplete();
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h2 className="text-3xl font-bold text-blue-600">Spam Detection Sim</h2>
        <p className="text-gray-500">See how simple ML algorithms detect junk mail.</p>
      </div>

      <div className="bg-white p-10 rounded-3xl border shadow-sm space-y-8">
        <textarea
          placeholder="Paste a suspicious email here..."
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full h-48 p-6 rounded-2xl border bg-gray-50 resize-none focus:ring-4 focus:ring-blue-100 outline-none text-xl transition-all"
        />
        <button 
          onClick={analyze} 
          disabled={!email.trim()}
          className="w-full py-5 bg-blue-600 text-white rounded-2xl font-bold text-xl shadow-lg hover:bg-blue-700 disabled:opacity-50 transition-all"
        >
          Analyze Message
        </button>

        {result && (
          <div className={`p-8 rounded-3xl border-2 animate-in slide-in-from-bottom-4 ${
            result.isSpam ? 'border-red-100 bg-red-50' : 'border-green-100 bg-green-50'
          }`}>
            <div className="flex items-center gap-6 mb-6">
              {result.isSpam ? <ShieldAlert className="w-12 h-12 text-red-500" /> : <ShieldCheck className="w-12 h-12 text-green-500" />}
              <div>
                <p className="text-3xl font-black text-gray-900">{result.isSpam ? 'SPAM DETECTED' : 'LEGITIMATE'}</p>
                <p className="text-gray-600 font-medium">Pattern Match Confidence: {result.confidence}%</p>
              </div>
            </div>
            <div className="w-full bg-gray-200 h-4 rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all duration-1000 ${result.isSpam ? 'bg-red-500' : 'bg-green-500'}`} 
                style={{ width: `${result.confidence}%` }}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
