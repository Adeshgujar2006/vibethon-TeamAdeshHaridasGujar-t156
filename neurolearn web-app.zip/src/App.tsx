import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Brain, BookOpen, Zap, Trophy, Mail, ShieldAlert, ShieldCheck, 
  CheckCircle2, XCircle, LogIn, LogOut, Layout, ArrowRight, 
  ChevronRight, Star, MessageSquare, Send, LineChart, BarChart3, 
  GitBranch, Info, PlayCircle, Award, Sparkles, HelpCircle,
  Network, Layers, Target, Cpu, Database, Search
} from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js';
import { Line, Bar, Pie } from 'react-chartjs-2';
import ReactMarkdown from 'react-markdown';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

// --- Types ---
interface UserData {
  username: string;
  score: number;
  streak: number;
  lastActivity: string;
  completedModules: string[];
  badges: string[];
}

// --- Static Data ---
const MODULES = [
  {
    id: 'linear-regression',
    level: 'Beginner',
    title: 'Linear Regression',
    icon: LineChart,
    description: 'Predicting values based on relationships.',
    content: 'Linear Regression is used to predict a continuous value. For example, predicting house prices based on square footage. It finds the "best fit" line through data points.',
    example: 'A real estate app predicting your home value as you add more rooms.',
    quiz: [
      { q: 'What does Linear Regression find?', a: ['The best fit line', 'A random point', 'A circle', 'A hidden layer'], c: 0 },
      { q: 'Which is a continuous value?', a: ['Cat vs Dog', 'House Price', 'Spam vs Not Spam', 'True vs False'], c: 1 },
      { q: 'Linear Regression is part of...', a: ['Supervised Learning', 'Unsupervised Learning', 'Reinforcement Learning', 'None'], c: 0 }
    ]
  },
  {
    id: 'neural-networks',
    level: 'Intermediate',
    title: 'Neural Networks',
    icon: Brain,
    description: 'Mimicking the human brain to solve complex tasks.',
    content: 'Neural Networks consist of layers of neurons. They are excellent at recognizing patterns in images, voice, and text.',
    example: 'Face ID on your phone recognizing your face even with glasses.',
    quiz: [
      { q: 'What are the layers in a Neural Net?', a: ['Input, Hidden, Output', 'Start, Middle, End', 'Top, Bottom', 'Left, Right'], c: 0 },
      { q: 'Neural Nets are inspired by...', a: ['The Internet', 'The Human Brain', 'A Library', 'A Factory'], c: 1 },
      { q: 'Which layer detects patterns?', a: ['Input', 'Hidden', 'Output', 'None'], c: 1 }
    ]
  },
  {
    id: 'classification',
    level: 'Beginner',
    title: 'Classification',
    icon: BarChart3,
    description: 'Grouping data into specific categories.',
    content: 'Classification is about assigning labels. Is this email spam? Is this image a cat? It predicts discrete categories.',
    example: 'Your email provider moving a "Win a Prize" email to the Spam folder.',
    quiz: [
      { q: 'Classification predicts...', a: ['Continuous values', 'Discrete labels', 'Random numbers', 'Nothing'], c: 1 },
      { q: 'Which is a classification task?', a: ['Predicting temperature', 'Spam detection', 'Stock price prediction', 'Height prediction'], c: 1 },
      { q: 'A binary classifier has...', a: ['1 category', '2 categories', '10 categories', 'Infinite categories'], c: 1 }
    ]
  },
  {
    id: 'decision-trees',
    level: 'Beginner',
    title: 'Decision Trees',
    icon: GitBranch,
    description: 'Making decisions using a flowchart-like structure.',
    content: 'Decision Trees split data based on features. It asks a series of Yes/No questions to reach a final decision.',
    example: 'A bank deciding to approve a loan based on credit score and income.',
    quiz: [
      { q: 'What structure does a Decision Tree use?', a: ['A circle', 'A flowchart', 'A straight line', 'A cloud'], c: 1 },
      { q: 'The final nodes are called...', a: ['Roots', 'Branches', 'Leaves', 'Trunks'], c: 2 },
      { q: 'Decision Trees can be used for...', a: ['Classification only', 'Regression only', 'Both', 'Neither'], c: 2 }
    ]
  },
  {
    id: 'svm',
    level: 'Advanced',
    title: 'Support Vector Machines',
    icon: Target,
    description: 'Finding the optimal boundary between classes.',
    content: 'SVM finds the hyperplane that best separates different classes with the maximum margin.',
    example: 'Classifying whether a tumor is malignant or benign based on its characteristics.',
    quiz: [
      { q: 'What is the "Hyperplane" in SVM?', a: ['A 3D model', 'The decision boundary', 'A hidden neuron', 'A data point'], c: 1 },
      { q: 'SVM aims to maximize the...', a: ['Error', 'Margin', 'Speed', 'Complexity'], c: 1 },
      { q: 'Can SVM be used for non-linear data?', a: ['Yes, using kernels', 'No, only linear', 'Only for text', 'Only for images'], c: 0 }
    ]
  },
  {
    id: 'k-means',
    level: 'Intermediate',
    title: 'K-Means Clustering',
    icon: Network,
    description: 'Grouping similar data points without labels.',
    content: 'K-Means is an unsupervised learning algorithm that groups data into K clusters based on similarity.',
    example: 'E-commerce sites grouping customers with similar buying habits for targeted ads.',
    quiz: [
      { q: 'K-Means is what type of learning?', a: ['Supervised', 'Unsupervised', 'Reinforcement', 'Deep Learning'], c: 1 },
      { q: 'What does "K" represent?', a: ['Kilograms', 'Number of clusters', 'Kernel size', 'Knowledge level'], c: 1 },
      { q: 'How does it find clusters?', a: ['By asking questions', 'By minimizing distance to centroids', 'By drawing lines', 'By using neurons'], c: 1 }
    ]
  },
  {
    id: 'random-forest',
    level: 'Advanced',
    title: 'Random Forest',
    icon: Layers,
    description: 'An ensemble of decision trees for better accuracy.',
    content: 'Random Forest combines multiple decision trees to create a "forest". It takes the average or majority vote of all trees to make a final prediction.',
    example: 'Predicting whether a bank transaction is fraudulent by checking multiple factors across many trees.',
    quiz: [
      { q: 'What is a Random Forest?', a: ['A single tree', 'A collection of decision trees', 'A neural network', 'A database'], c: 1 },
      { q: 'Why use Random Forest over a single tree?', a: ['It is faster', 'It is more accurate and stable', 'It uses less memory', 'It is simpler'], c: 1 },
      { q: 'How does it reach a final decision?', a: ['Random guess', 'Majority vote/Average', 'First tree wins', 'Last tree wins'], c: 1 }
    ]
  },
  {
    id: 'pca',
    level: 'Advanced',
    title: 'PCA',
    icon: Cpu,
    description: 'Reducing complexity while keeping important info.',
    content: 'Principal Component Analysis (PCA) reduces the number of variables in a dataset while preserving as much information as possible.',
    example: 'Compressing a high-resolution image into a smaller file while keeping it recognizable.',
    quiz: [
      { q: 'What does PCA stand for?', a: ['Primary Computer Analysis', 'Principal Component Analysis', 'Private Cloud Access', 'Point Cloud Area'], c: 1 },
      { q: 'What is the main goal of PCA?', a: ['Increase data size', 'Dimensionality reduction', 'Data encryption', 'Data deletion'], c: 1 },
      { q: 'PCA is useful when you have...', a: ['Too little data', 'Too many features', 'No labels', 'No computers'], c: 1 }
    ]
  },
  {
    id: 'knn',
    level: 'Intermediate',
    title: 'K-Nearest Neighbors',
    icon: Search,
    description: 'Classifying data based on its closest neighbors.',
    content: 'KNN classifies a data point based on how its neighbors are classified. If most of your neighbors are "Apples", you are likely an "Apple".',
    example: 'Recommending movies similar to the ones you just watched.',
    quiz: [
      { q: 'What does KNN stand for?', a: ['Kernel Neural Network', 'K-Nearest Neighbors', 'Key Node Network', 'Knowledge Node Network'], c: 1 },
      { q: 'How does KNN classify a point?', a: ['By asking its neighbors', 'By using a tree', 'By drawing a line', 'By random choice'], c: 0 },
      { q: 'What is "K" in KNN?', a: ['Number of clusters', 'Number of neighbors to check', 'Kernel size', 'Knowledge level'], c: 1 }
    ]
  }
];

// --- Main App ---
export default function App() {
  const [user, setUser] = useState<UserData | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedModule, setSelectedModule] = useState<any>(null);
  const [leaderboard, setLeaderboard] = useState<UserData[]>([]);
  const [loginInput, setLoginInput] = useState('');

  // Initialize
  useEffect(() => {
    const savedUser = localStorage.getItem('neuro_current_user');
    const savedLeaderboard = JSON.parse(localStorage.getItem('neuro_leaderboard') || '[]');
    setLeaderboard(savedLeaderboard);
    if (savedUser) {
      const userData = savedLeaderboard.find((u: UserData) => u.username === savedUser);
      if (userData) {
        setUser({
          ...userData,
          completedModules: userData.completedModules || [],
          badges: userData.badges || []
        });
      }
    }
  }, []);

  // Save Leaderboard
  useEffect(() => {
    if (leaderboard.length > 0) {
      localStorage.setItem('neuro_leaderboard', JSON.stringify(leaderboard));
    }
  }, [leaderboard]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginInput.trim()) return;
    
    let existingUser = leaderboard.find(u => u.username === loginInput.trim());
    if (!existingUser) {
      existingUser = {
        username: loginInput.trim(),
        score: 0,
        streak: 1,
        lastActivity: new Date().toISOString(),
        completedModules: [],
        badges: []
      };
      setLeaderboard([...leaderboard, existingUser]);
    }
    setUser(existingUser);
    localStorage.setItem('neuro_current_user', existingUser.username);
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('neuro_current_user');
    setActiveTab('dashboard');
  };

  const updateScore = (points: number, moduleId?: string) => {
    if (!user) return;
    const updatedLeaderboard = leaderboard.map(u => {
      if (u.username === user.username) {
        const newScore = u.score + points;
        const newStreak = u.streak + 1;
        const newCompleted = (moduleId && u.completedModules && !u.completedModules.includes(moduleId))
          ? [...u.completedModules, moduleId] 
          : (u.completedModules || []);
        
        // Badge Logic
        const newBadges = [...(u.badges || [])];
        if (newScore >= 100 && !newBadges.includes('Novice')) newBadges.push('Novice');
        if (newScore >= 500 && !newBadges.includes('Expert')) newBadges.push('Expert');
        if (newScore >= 1000 && !newBadges.includes('Master')) newBadges.push('Master');
        if (newCompleted.length >= 5 && !newBadges.includes('Scholar')) newBadges.push('Scholar');

        const updated = { 
          ...u, 
          score: newScore, 
          streak: newStreak, 
          lastActivity: new Date().toISOString(),
          completedModules: newCompleted,
          badges: newBadges
        };
        setUser(updated);
        return updated;
      }
      return u;
    });
    setLeaderboard(updatedLeaderboard);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-6 font-sans">
        <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-10 space-y-8 text-center">
          <div className="flex justify-center">
            <div className="p-4 bg-blue-600 rounded-2xl shadow-lg shadow-blue-500/20">
              <Brain className="w-12 h-12 text-white" />
            </div>
          </div>
          <div className="space-y-2">
            <h1 className="text-4xl font-black tracking-tighter text-white">NEUROLE <span className="text-blue-500">ARN</span></h1>
            <p className="text-slate-400">Your gateway to mastering Artificial Intelligence.</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-4">
            <input
              type="text"
              placeholder="Enter your username"
              value={loginInput}
              onChange={(e) => setLoginInput(e.target.value)}
              className="w-full p-4 rounded-xl bg-slate-800 border border-slate-700 text-white focus:border-blue-500 outline-none transition-all text-center text-lg"
              required
            />
            <button type="submit" className="w-full py-4 bg-blue-600 text-white rounded-xl font-bold text-lg shadow-lg hover:bg-blue-500 transition-all flex items-center justify-center gap-2">
              <LogIn className="w-5 h-5" /> Start Exploring
            </button>
          </form>
        </div>
      </div>
    );
  }

  const renderContent = () => {
    if (selectedModule) return <ModuleView module={selectedModule} onBack={() => setSelectedModule(null)} onComplete={(pts: number) => updateScore(pts, selectedModule.id)} />;
    
    switch (activeTab) {
      case 'dashboard': return <Dashboard user={user} leaderboard={leaderboard} onStartModule={setSelectedModule} />;
      case 'learn': return <LearnGrid onStartModule={setSelectedModule} />;
      case 'simulation': return <SimulationSection onComplete={() => updateScore(50)} />;
      case 'playground': return <CodingPlayground onComplete={() => updateScore(100)} />;
      case 'games': return <MiniGames onComplete={(pts: number) => updateScore(pts)} />;
      case 'chatbot': return <ChatbotSection />;
      default: return <Dashboard user={user} leaderboard={leaderboard} onStartModule={setSelectedModule} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 flex flex-col md:flex-row">
      {/* Sidebar */}
      <aside className="w-full md:w-72 bg-slate-900 border-r border-slate-800 p-6 flex flex-col gap-8">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-600 rounded-lg">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <span className="font-black text-2xl tracking-tighter text-white">NEUROLE <span className="text-blue-500">ARN</span></span>
        </div>

        <nav className="flex-1 space-y-2">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: Layout },
            { id: 'learn', label: 'Modules', icon: BookOpen },
            { id: 'playground', label: 'Code Lab', icon: Cpu },
            { id: 'games', label: 'Mini Games', icon: Zap },
            { id: 'simulation', label: 'Playground', icon: Search },
            { id: 'chatbot', label: 'AI Tutor', icon: Sparkles },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => { setActiveTab(item.id); setSelectedModule(null); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                activeTab === item.id ? 'bg-blue-600/10 text-blue-400 font-bold border border-blue-500/20' : 'text-slate-500 hover:bg-slate-800 hover:text-slate-300'
              }`}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="pt-6 border-t border-slate-800">
          <div className="flex items-center gap-3 mb-6 px-2">
            <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center font-bold text-blue-500 border border-slate-700">
              {user?.username?.[0]?.toUpperCase() || '?'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold truncate text-white">{user?.username || 'Guest'}</p>
              <p className="text-xs text-slate-500">Level: {(user?.score || 0) > 1000 ? 'Master' : (user?.score || 0) > 500 ? 'Expert' : 'Novice'}</p>
            </div>
          </div>
          <button onClick={handleLogout} className="w-full flex items-center gap-3 px-4 py-3 text-red-400 hover:bg-red-500/10 rounded-xl transition-all font-medium">
            <LogOut className="w-5 h-5" /> Logout
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 p-6 md:p-12 overflow-y-auto">
        {renderContent()}
      </main>
    </div>
  );
}

// --- Sub-Components ---

function Dashboard({ user, leaderboard, onStartModule }: any) {
  const sortedLeaderboard = useMemo(() => [...leaderboard].sort((a, b) => b.score - a.score), [leaderboard]);
  const badge = user.score > 1000 ? 'Master' : user.score > 500 ? 'Intermediate' : 'Beginner';

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col lg:flex-row gap-8">
        <div className="flex-1 space-y-8">
          <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-10 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
            <div className="relative z-10">
              <h2 className="text-4xl font-black text-white mb-2">Hello, {user.username}! 👋</h2>
              <p className="text-blue-100 text-lg max-w-md">Ready to continue your AI journey? You've earned {user.score} points so far.</p>
              <div className="mt-8 flex gap-4">
                <div className="px-6 py-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20">
                  <p className="text-xs text-blue-200 font-bold uppercase tracking-widest">Streak</p>
                  <p className="text-2xl font-black text-white">{user.streak} Days</p>
                </div>
                <div className="px-6 py-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20">
                  <p className="text-xs text-blue-200 font-bold uppercase tracking-widest">Badge</p>
                  <p className="text-2xl font-black text-white">{badge}</p>
                </div>
              </div>
            </div>
            <Brain className="absolute -right-10 -bottom-10 w-64 h-64 text-white/5 rotate-12" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 space-y-4">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <Award className="w-5 h-5 text-yellow-500" /> Your Badges
              </h3>
              <div className="flex flex-wrap gap-2">
                {(user?.badges?.length || 0) > 0 ? user.badges.map((b: string) => (
                  <span key={b} className="px-3 py-1 bg-blue-600/20 text-blue-400 rounded-full text-xs font-bold border border-blue-500/30">
                    {b}
                  </span>
                )) : <p className="text-slate-500 text-sm">No badges yet. Keep learning!</p>}
              </div>
            </div>
            <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 space-y-4">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-500" /> Progress
              </h3>
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-bold text-slate-400">
                  <span>Modules Completed</span>
                  <span>{user?.completedModules?.length || 0} / {MODULES.length}</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div className="bg-green-500 h-full transition-all" style={{ width: `${((user?.completedModules?.length || 0) / MODULES.length) * 100}%` }} />
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {MODULES.slice(0, 4).map(m => (
              <div key={m.id} onClick={() => onStartModule(m)} className="bg-slate-900 p-6 rounded-3xl border border-slate-800 hover:border-blue-500/50 transition-all cursor-pointer group">
                <div className="flex justify-between items-start mb-4">
                  <div className="w-12 h-12 bg-slate-800 rounded-2xl flex items-center justify-center group-hover:bg-blue-600 transition-colors">
                    <m.icon className="w-6 h-6 text-blue-500 group-hover:text-white" />
                  </div>
                  <span className={`text-[10px] font-black uppercase tracking-widest px-2 py-1 rounded-md ${
                    m.level === 'Beginner' ? 'bg-green-500/10 text-green-500' : 
                    m.level === 'Intermediate' ? 'bg-yellow-500/10 text-yellow-500' : 'bg-red-500/10 text-red-500'
                  }`}>
                    {m.level}
                  </span>
                </div>
                <h4 className="text-xl font-bold text-white mb-2">{m.title}</h4>
                <p className="text-slate-400 text-sm mb-4 line-clamp-2">{m.description}</p>
                <button className="text-blue-500 font-bold flex items-center gap-2 text-sm">
                  {user?.completedModules?.includes(m.id) ? 'Review' : 'Start'} <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="w-full lg:w-80 space-y-6">
          <h3 className="text-xl font-bold flex items-center gap-2 text-white">
            <Trophy className="w-5 h-5 text-yellow-500" /> Leaderboard
          </h3>
          <div className="bg-slate-900 rounded-3xl border border-slate-800 overflow-hidden">
            <div className="divide-y divide-slate-800">
              {sortedLeaderboard.map((u, i) => (
                <div key={i} className={`p-4 flex items-center justify-between ${u.username === user.username ? 'bg-blue-600/5' : ''}`}>
                  <div className="flex items-center gap-3">
                    <span className={`font-black text-sm ${i < 3 ? 'text-yellow-500' : 'text-slate-600'}`}>#{i + 1}</span>
                    <span className={`font-bold text-sm ${u.username === user.username ? 'text-blue-400' : 'text-slate-300'}`}>{u.username}</span>
                  </div>
                  <span className="font-black text-slate-400 text-sm">{u.score}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function CodingPlayground({ onComplete }: any) {
  const [code, setCode] = useState(`# Welcome to NeuroLearn Code Lab!
# Try this simple Linear Regression example:

import math

def predict_price(sqft, price_per_sqft):
    return sqft * price_per_sqft

sqft = 1500
price_per_sqft = 200
prediction = predict_price(sqft, price_per_sqft)

print(f"Predicted House Price: \${prediction}")
`);
  const [output, setOutput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const pyodideRef = useRef<any>(null);

  useEffect(() => {
    const initPyodide = async () => {
      if ((window as any).loadPyodide) {
        setIsLoading(true);
        pyodideRef.current = await (window as any).loadPyodide();
        setIsLoading(false);
      }
    };
    initPyodide();
  }, []);

  const runCode = async () => {
    if (!pyodideRef.current) return;
    setOutput('Running...');
    try {
      // Redirect stdout to capture print statements
      pyodideRef.current.runPython(`
import sys
import io
sys.stdout = io.StringIO()
`);
      await pyodideRef.current.runPythonAsync(code);
      const stdout = pyodideRef.current.runPython("sys.stdout.getvalue()");
      setOutput(stdout || 'Code executed successfully (no output).');
      onComplete();
    } catch (err: any) {
      setOutput(`Error: ${err.message}`);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="max-w-2xl">
        <h2 className="text-4xl font-black text-white mb-2">Interactive Code Lab</h2>
        <p className="text-slate-400 text-lg">Write and execute Python code directly in your browser using Pyodide.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-[600px]">
        <div className="bg-slate-900 rounded-3xl border border-slate-800 flex flex-col overflow-hidden shadow-2xl">
          <div className="p-4 bg-slate-800 border-b border-slate-700 flex justify-between items-center">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Python Editor</span>
            <button 
              onClick={runCode} 
              disabled={isLoading}
              className="px-4 py-2 bg-green-600 text-white rounded-lg font-bold text-sm hover:bg-green-500 transition-all flex items-center gap-2"
            >
              <PlayCircle className="w-4 h-4" /> {isLoading ? 'Loading...' : 'Run Code'}
            </button>
          </div>
          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="flex-1 p-6 bg-slate-950 text-blue-400 font-mono text-sm outline-none resize-none"
            spellCheck={false}
          />
        </div>

        <div className="bg-slate-900 rounded-3xl border border-slate-800 flex flex-col overflow-hidden shadow-2xl">
          <div className="p-4 bg-slate-800 border-b border-slate-700">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Console Output</span>
          </div>
          <pre className="flex-1 p-6 bg-slate-950 text-slate-300 font-mono text-sm overflow-auto whitespace-pre-wrap">
            {output || 'Output will appear here...'}
          </pre>
        </div>
      </div>
    </div>
  );
}

function MiniGames({ onComplete }: any) {
  const [activeGame, setActiveGame] = useState<string | null>(null);

  const renderGame = () => {
    if (activeGame === 'classification') {
      return <ClassificationGame onFinish={(pts: number) => { onComplete(pts); setActiveGame(null); }} />;
    }
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div onClick={() => setActiveGame('classification')} className="bg-slate-900 p-10 rounded-[2.5rem] border border-slate-800 hover:border-blue-500/50 transition-all cursor-pointer group relative overflow-hidden">
          <div className="relative z-10">
            <div className="w-16 h-16 bg-blue-600/10 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-blue-600 transition-colors">
              <Target className="w-8 h-8 text-blue-500 group-hover:text-white" />
            </div>
            <h3 className="text-3xl font-bold text-white mb-4">Fast Classifier</h3>
            <p className="text-slate-400 text-lg mb-8">Sort objects into categories as fast as you can. Teaches binary classification!</p>
            <button className="px-8 py-3 bg-blue-600 text-white rounded-xl font-bold flex items-center gap-2">
              Play Now <ArrowRight className="w-5 h-5" />
            </button>
          </div>
          <Target className="absolute -right-10 -bottom-10 w-64 h-64 text-white/5 group-hover:text-blue-500/5 transition-colors" />
        </div>
        {/* Add more games here */}
      </div>
    );
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="max-w-2xl">
        <h2 className="text-4xl font-black text-white mb-2">Mini Games</h2>
        <p className="text-slate-400 text-lg">Learn AIML concepts through fun, interactive challenges.</p>
      </div>
      {renderGame()}
    </div>
  );
}

function ClassificationGame({ onFinish }: any) {
  const objects = [
    { name: 'Apple', type: 'Fruit' },
    { name: 'Carrot', type: 'Veggie' },
    { name: 'Banana', type: 'Fruit' },
    { name: 'Broccoli', type: 'Veggie' },
    { name: 'Grape', type: 'Fruit' },
    { name: 'Spinach', type: 'Veggie' },
  ];
  const [currentIdx, setCurrentIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(10);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      onFinish(score * 10);
    }
  }, [timeLeft]);

  const handleChoice = (type: string) => {
    if (type === objects[currentIdx].type) {
      setScore(s => s + 1);
    }
    if (currentIdx < objects.length - 1) {
      setCurrentIdx(currentIdx + 1);
    } else {
      onFinish(score * 10);
    }
  };

  return (
    <div className="max-w-md mx-auto bg-slate-900 p-10 rounded-[2.5rem] border border-slate-800 text-center space-y-8 shadow-2xl">
      <div className="flex justify-between items-center text-xs font-bold text-slate-500 uppercase tracking-widest">
        <span>Time: {timeLeft}s</span>
        <span className="text-blue-500">Score: {score}</span>
      </div>
      <div className="space-y-4">
        <p className="text-slate-400 font-bold uppercase tracking-widest text-sm">Classify this:</p>
        <h2 className="text-5xl font-black text-white">{objects[currentIdx].name}</h2>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <button onClick={() => handleChoice('Fruit')} className="py-6 bg-blue-600 text-white rounded-2xl font-bold text-xl hover:bg-blue-500 transition-all">Fruit</button>
        <button onClick={() => handleChoice('Veggie')} className="py-6 bg-indigo-600 text-white rounded-2xl font-bold text-xl hover:bg-indigo-500 transition-all">Veggie</button>
      </div>
    </div>
  );
}

function VoiceExplanation({ text }: { text: string }) {
  const speak = () => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.9;
    window.speechSynthesis.speak(utterance);
  };

  return (
    <button onClick={speak} className="p-2 bg-blue-600/10 text-blue-500 rounded-lg hover:bg-blue-600 hover:text-white transition-all">
      <Zap className="w-4 h-4" />
    </button>
  );
}


function LearnGrid({ onStartModule }: any) {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="max-w-2xl">
        <h2 className="text-4xl font-black text-white mb-2">Learning Modules</h2>
        <p className="text-slate-400 text-lg">Master the core concepts of Machine Learning through interactive lessons and quizzes.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {MODULES.map(m => (
          <div key={m.id} onClick={() => onStartModule(m)} className="bg-slate-900 p-8 rounded-[2rem] border border-slate-800 hover:border-blue-500/50 transition-all cursor-pointer group relative overflow-hidden">
            <div className="relative z-10">
              <div className="w-14 h-14 bg-slate-800 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-blue-600 transition-colors">
                <m.icon className="w-7 h-7 text-blue-500 group-hover:text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-3">{m.title}</h3>
              <p className="text-slate-400 leading-relaxed mb-6">{m.description}</p>
              <div className="flex items-center gap-2 text-blue-500 font-bold">
                Start Module <ChevronRight className="w-5 h-5" />
              </div>
            </div>
            <m.icon className="absolute -right-10 -bottom-10 w-48 h-48 text-white/5 group-hover:text-blue-500/5 transition-colors" />
          </div>
        ))}
      </div>
    </div>
  );
}

function ModuleView({ module, onBack, onComplete }: any) {
  const [step, setStep] = useState('content'); // content, interactive, quiz
  const [quizScore, setQuizScore] = useState(0);
  const [currentQ, setCurrentQ] = useState(0);
  const [answered, setAnswered] = useState(false);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);

  // Interactive State for Linear Regression
  const [lrValue, setLrValue] = useState(5);

  const handleQuizAnswer = (idx: number) => {
    if (answered) return;
    setSelectedOpt(idx);
    setAnswered(true);
    if (idx === module.quiz[currentQ].c) setQuizScore(s => s + 1);
  };

  const nextQuizStep = () => {
    if (currentQ < module.quiz.length - 1) {
      setCurrentQ(c => c + 1);
      setAnswered(false);
      setSelectedOpt(null);
    } else {
      onComplete(quizScore * 50);
      setStep('result');
    }
  };

  const renderInteractive = () => {
    if (module.id === 'linear-regression') {
      const data = {
        labels: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        datasets: [
          {
            label: 'Predicted Value',
            data: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(x => x * lrValue),
            borderColor: '#3b82f6',
            backgroundColor: 'rgba(59, 130, 246, 0.5)',
            tension: 0.1,
          },
        ],
      };
      return (
        <div className="space-y-6">
          <div className="bg-slate-800 p-6 rounded-2xl">
            <Line data={data} options={{ responsive: true, scales: { y: { min: 0, max: 100 } } }} />
          </div>
          <div className="space-y-4">
            <label className="text-sm font-bold text-slate-400 uppercase tracking-widest">Adjust Slope (m): {lrValue}</label>
            <input 
              type="range" min="1" max="10" value={lrValue} 
              onChange={(e) => setLrValue(parseInt(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
            <p className="text-sm text-slate-500 italic">Equation: y = {lrValue}x</p>
          </div>
        </div>
      );
    }
    
    if (module.id === 'classification') {
      const data = {
        labels: ['Spam', 'Legit'],
        datasets: [
          {
            label: 'Probability',
            data: [0.85, 0.15],
            backgroundColor: ['#ef4444', '#22c55e'],
          },
        ],
      };
      return (
        <div className="space-y-6">
          <div className="bg-slate-800 p-6 rounded-2xl">
            <Bar data={data} options={{ responsive: true }} />
          </div>
          <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700">
            <p className="text-sm text-slate-400">The model predicts an 85% chance this email is Spam based on keywords like "Win" and "Free".</p>
          </div>
        </div>
      );
    }

    return (
      <div className="p-12 bg-slate-800 rounded-3xl flex flex-col items-center justify-center text-center space-y-4">
        <PlayCircle className="w-16 h-16 text-blue-500" />
        <p className="text-slate-400">Interactive simulation for {module.title} is ready.</p>
        <button className="px-6 py-2 bg-blue-600 text-white rounded-xl font-bold">Launch Demo</button>
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in slide-in-from-right-8 duration-500">
      <button onClick={onBack} className="text-slate-500 hover:text-white flex items-center gap-2 transition-colors font-bold">
        <ArrowRight className="w-4 h-4 rotate-180" /> Back to Modules
      </button>

      {step === 'content' && (
        <div className="bg-slate-900 p-10 rounded-[2.5rem] border border-slate-800 space-y-8 shadow-2xl">
            <div className="flex items-center gap-4">
              <div className="p-4 bg-blue-600 rounded-2xl">
                <module.icon className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1">
                <h2 className="text-4xl font-black text-white">{module.title}</h2>
                <div className="mt-2">
                  <VoiceExplanation text={module.content} />
                </div>
              </div>
            </div>
          <div className="space-y-6">
            <div className="p-6 bg-slate-800/50 rounded-2xl border border-slate-700">
              <h4 className="text-blue-400 font-bold mb-2 flex items-center gap-2"><Info className="w-4 h-4" /> Concept</h4>
              <p className="text-slate-300 text-lg leading-relaxed">{module.content}</p>
            </div>
            <div className="p-6 bg-slate-800/50 rounded-2xl border border-slate-700">
              <h4 className="text-green-400 font-bold mb-2 flex items-center gap-2"><Zap className="w-4 h-4" /> Real-World Example</h4>
              <p className="text-slate-300 text-lg leading-relaxed">{module.example}</p>
            </div>
          </div>
          <button onClick={() => setStep('interactive')} className="w-full py-5 bg-blue-600 text-white rounded-2xl font-bold text-xl shadow-lg hover:bg-blue-500 transition-all flex items-center justify-center gap-3">
            Try Interactive Demo <ArrowRight className="w-6 h-6" />
          </button>
        </div>
      )}

      {step === 'interactive' && (
        <div className="bg-slate-900 p-10 rounded-[2.5rem] border border-slate-800 space-y-8 shadow-2xl">
          <h2 className="text-3xl font-black text-white">Visualizing {module.title}</h2>
          {renderInteractive()}
          <button onClick={() => setStep('quiz')} className="w-full py-5 bg-blue-600 text-white rounded-2xl font-bold text-xl shadow-lg hover:bg-blue-500 transition-all">
            Take the Quiz
          </button>
        </div>
      )}

      {step === 'quiz' && (
        <div className="max-w-2xl mx-auto space-y-6">
          <div className="flex justify-between items-center text-xs font-bold text-slate-500 uppercase tracking-widest">
            <span>Question {currentQ + 1} of {module.quiz.length}</span>
            <span className="text-blue-500">Score: {quizScore}</span>
          </div>
          <div className="bg-slate-900 p-10 rounded-[2.5rem] border border-slate-800 space-y-8 shadow-2xl">
            <h3 className="text-2xl font-bold text-white leading-tight">{module.quiz[currentQ].q}</h3>
            <div className="space-y-3">
              {module.quiz[currentQ].a.map((opt: string, i: number) => (
                <button
                  key={i}
                  onClick={() => handleQuizAnswer(i)}
                  className={`w-full p-5 text-left rounded-2xl border-2 transition-all font-bold text-lg ${
                    answered 
                      ? i === module.quiz[currentQ].c 
                        ? 'border-green-500 bg-green-500/10 text-green-400' 
                        : selectedOpt === i ? 'border-red-500 bg-red-500/10 text-red-400' : 'border-slate-800 text-slate-600'
                      : selectedOpt === i ? 'border-blue-600 bg-blue-600/10 text-blue-400' : 'border-slate-800 hover:border-slate-700 text-slate-400'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span>{opt}</span>
                    {answered && i === module.quiz[currentQ].c && <CheckCircle2 className="w-6 h-6" />}
                    {answered && selectedOpt === i && i !== module.quiz[currentQ].c && <XCircle className="w-6 h-6" />}
                  </div>
                </button>
              ))}
            </div>
            {answered && (
              <button onClick={nextQuizStep} className="w-full py-5 bg-slate-100 text-slate-900 rounded-2xl font-bold text-lg shadow-xl hover:bg-white transition-all">
                {currentQ < module.quiz.length - 1 ? 'Next Question' : 'Finish Quiz'}
              </button>
            )}
          </div>
        </div>
      )}

      {step === 'result' && (
        <div className="text-center space-y-8 py-20 animate-in zoom-in duration-500">
          <div className="inline-block p-8 bg-blue-600 rounded-full shadow-2xl shadow-blue-500/40">
            <Award className="w-20 h-20 text-white" />
          </div>
          <div className="space-y-2">
            <h2 className="text-5xl font-black text-white">Great Job!</h2>
            <p className="text-xl text-slate-400">You earned <span className="text-blue-500 font-bold">+{quizScore * 50} points</span> for completing this module.</p>
          </div>
          <button onClick={onBack} className="px-12 py-4 bg-blue-600 text-white rounded-2xl font-bold text-xl shadow-lg hover:bg-blue-500 transition-all">
            Back to Dashboard
          </button>
        </div>
      )}
    </div>
  );
}

function SimulationSection({ onComplete }: any) {
  const [email, setEmail] = useState('');
  const [result, setResult] = useState<{ isSpam: boolean; confidence: number } | null>(null);

  const spamKeywords = ['win', 'prize', 'urgent', 'account', 'verify', 'bank', 'lottery', 'free', 'click', 'congratulations', 'money'];

  const analyze = () => {
    const lower = email.toLowerCase();
    const matches = spamKeywords.filter(word => lower.includes(word));
    const confidence = Math.min(matches.length * 20, 99);
    setResult({ isSpam: matches.length > 0, confidence });
    onComplete();
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="max-w-2xl">
        <h2 className="text-4xl font-black text-white mb-2">Spam Detection Lab</h2>
        <p className="text-slate-400 text-lg">Test how keyword-based classification works in real-time.</p>
      </div>

      <div className="bg-slate-900 p-10 rounded-[2.5rem] border border-slate-800 space-y-8 shadow-2xl">
        <div className="space-y-4">
          <label className="text-sm font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
            <Mail className="w-4 h-4" /> Email Content
          </label>
          <textarea
            placeholder="Paste a suspicious email message here..."
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full h-48 p-6 rounded-2xl bg-slate-800 border border-slate-700 text-white resize-none focus:ring-4 focus:ring-blue-500/20 outline-none text-xl transition-all"
          />
        </div>
        <button 
          onClick={analyze} 
          disabled={!email.trim()}
          className="w-full py-5 bg-blue-600 text-white rounded-2xl font-bold text-xl shadow-lg hover:bg-blue-500 disabled:opacity-50 transition-all"
        >
          Analyze Message
        </button>

        {result && (
          <div className={`p-8 rounded-3xl border-2 animate-in slide-in-from-bottom-4 ${
            result.isSpam ? 'border-red-500/20 bg-red-500/5' : 'border-green-500/20 bg-green-500/5'
          }`}>
            <div className="flex items-center gap-6 mb-6">
              {result.isSpam ? <ShieldAlert className="w-14 h-14 text-red-500" /> : <ShieldCheck className="w-14 h-14 text-green-500" />}
              <div>
                <p className={`text-3xl font-black ${result.isSpam ? 'text-red-500' : 'text-green-500'}`}>
                  {result.isSpam ? 'SPAM DETECTED' : 'LEGITIMATE'}
                </p>
                <p className="text-slate-400 font-medium">Model Confidence: {result.confidence}%</p>
              </div>
            </div>
            <div className="w-full bg-slate-800 h-4 rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all duration-1000 ${result.isSpam ? 'bg-red-500' : 'bg-green-500'}`} 
                style={{ width: `${result.confidence}%` }}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function ChatbotSection() {
  const [messages, setMessages] = useState([
    { role: 'bot', text: 'Hi! I am your AI Tutor. Ask me anything about Machine Learning, AI, or Data Science! I can provide detailed explanations, charts, and examples.' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg = { role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error("API Key missing. Please ensure GEMINI_API_KEY is set in your environment.");
      }

      const systemPrompt = `You are an expert AIML Tutor for the NeuroLearn app. 
      Your goal is to provide vast, detailed, and beginner-friendly explanations of all AIML concepts.
      When asked about a concept:
      1. Provide a clear paragraph explanation.
      2. Give real-world examples.
      3. Use Markdown for formatting (bold, lists, tables).
      4. If appropriate, provide data for a chart in a JSON block like this:
         \`\`\`chart
         {
           "type": "bar" | "line" | "pie",
           "labels": ["A", "B", "C"],
           "datasets": [{ "label": "Title", "data": [10, 20, 30] }]
         }
         \`\`\`
      Keep your tone encouraging and professional.`;

      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=${apiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{ role: 'user', parts: [{ text: input }] }],
          systemInstruction: { parts: [{ text: systemPrompt }] }
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error?.message || `API Error: ${response.status}`);
      }

      const data = await response.json();
      const botText = data.candidates?.[0]?.content?.parts?.[0]?.text;

      const botMsg = { 
        role: 'bot', 
        text: botText || "I'm sorry, I couldn't process that. Could you try rephrasing?" 
      };
      setMessages(prev => [...prev, botMsg]);
    } catch (error: any) {
      console.error("AI Error:", error);
      const errorMessage = error.message?.includes("API Key") 
        ? "AI Tutor configuration error: API Key is missing or invalid."
        : "Oops! I'm having trouble connecting to my brain. Please check your internet or try again later.";
      setMessages(prev => [...prev, { role: 'bot', text: errorMessage }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col space-y-6 animate-in fade-in duration-500">
      <div className="max-w-4xl">
        <h2 className="text-5xl font-black text-white mb-3">AI Doubt Solver</h2>
        <p className="text-slate-400 text-xl">Stuck on a concept? Ask our AI tutor for a vast explanation with charts and examples.</p>
      </div>

      <div className="flex-1 bg-slate-900 rounded-[3rem] border border-slate-800 flex flex-col overflow-hidden shadow-2xl">
        <div ref={scrollRef} className="flex-1 p-6 overflow-y-auto space-y-6">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] p-6 rounded-3xl text-sm leading-relaxed ${
                m.role === 'user' ? 'bg-blue-600 text-white rounded-tr-none shadow-lg' : 'bg-slate-800 text-slate-200 rounded-tl-none border border-slate-700'
              }`}>
                <div className="prose prose-invert max-w-none">
                  <ReactMarkdown
                    components={{
                      code({ node, inline, className, children, ...props }: any) {
                        const match = /language-(\w+)/.exec(className || '');
                        if (!inline && match && match[1] === 'chart') {
                          try {
                            const chartData = JSON.parse(String(children).replace(/\n/g, ''));
                            return <div className="my-4 bg-slate-950 p-4 rounded-xl border border-slate-700">
                              {chartData.type === 'bar' && <Bar data={chartData} options={{ responsive: true, plugins: { legend: { display: true } } }} />}
                              {chartData.type === 'line' && <Line data={chartData} options={{ responsive: true, plugins: { legend: { display: true } } }} />}
                              {chartData.type === 'pie' && <Pie data={chartData} options={{ responsive: true, plugins: { legend: { display: true } } }} />}
                            </div>;
                          } catch (e) {
                            return <code className={className} {...props}>{children}</code>;
                          }
                        }
                        return <code className={className} {...props}>{children}</code>;
                      }
                    }}
                  >
                    {m.text}
                  </ReactMarkdown>
                </div>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-slate-800 p-4 rounded-2xl rounded-tl-none border border-slate-700 flex gap-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" />
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce [animation-delay:0.4s]" />
              </div>
            </div>
          )}
        </div>
        <form onSubmit={handleSend} className="p-6 bg-slate-800/50 border-t border-slate-800 flex gap-4">
          <input
            type="text"
            placeholder="Ask about any AIML concept (e.g., 'Explain Random Forest with a chart')"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isLoading}
            className="flex-1 bg-slate-900 border border-slate-700 rounded-2xl px-6 py-4 text-white focus:border-blue-500 outline-none transition-all text-lg"
          />
          <button type="submit" disabled={isLoading} className="p-4 bg-blue-600 text-white rounded-2xl hover:bg-blue-500 transition-all disabled:opacity-50">
            <Send className="w-6 h-6" />
          </button>
        </form>
      </div>
    </div>
  );
}
